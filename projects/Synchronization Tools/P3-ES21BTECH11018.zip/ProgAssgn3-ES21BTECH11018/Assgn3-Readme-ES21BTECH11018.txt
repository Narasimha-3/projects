
INPUT :

Compile the code in terminal
during the execution of a.out, write the input file next to it as command line argument(ex:input.txt).

The input.txt file must be in the same directory as source code.

The input file must contain a single values of n,k,lambda1,lambda2 seperated by a space on first line.(Ex : 500 30 20 50)

Here N is number of threads to be used and K is number of times each thread to be executed.

OUTPUT :

output.txt file will be created.

A sample output is as follows:
TAS ME Output:
1st CS Requested at 10:00 by thread 1
1st CS Entered at 10:05 by thread 1
1st CS Exited at 10:06 by thread 1
1st CS Requested at 10:01 by thread 2
.
.
.
CAS ME Output:
1st CS Requested at 11:00 by thread 1
1st CS Entered at 11:05 by thread 1
1st CS Exited at 11:06 by thread 1
1st CS Requested at 11:01 by thread 2
.
.
.
Bounded CAS ME Output:
1st CS Requested at 11:30 by thread 1
1st CS Entered at 11:35 by thread 1
1st CS Exited at 11:36 by thread 1
1st CS Requested at 11:32 by thread 2
.
.
. 


Note : DELETE THE OUTPUT FILE BEFORE RUNNING OTHER CODE BECAUSE ALL CODE WILL RIGHT NEWLY AFTER PREVIOUS OUTPUTS WITHOUT ERASING.
