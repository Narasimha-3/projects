#include <iostream>
#include <cstdlib>
#include <ctime>
#include <atomic>
#include <pthread.h>
#include <fstream>
#include <random>
#include <unistd.h>
#include <chrono>
#include <time.h>

using namespace std ;
using namespace std::chrono ;
std::atomic_flag lock = ATOMIC_FLAG_INIT ; //lock variable atomic declaration

int N,K;
double lambda1,lambda2;

//gives random number with lambda as mean to exp dist 

double rand_exp(double lambda)
{
  unsigned random = system_clock::now().time_since_epoch().count();
  default_random_engine time (random);
  exponential_distribution<double>distribution(1/lambda) ;
  
  return distribution(time);
}


// executes code following TAS

void* pie(void*p)
{ 
  int*a = (int*)p; 
  int id = *a ;
  id++; // Thread id
    
    // All time variables to get system local time
    struct timespec ns;
    timespec_get(&ns,TIME_UTC);
    time_t now;
    now = time(NULL);
    struct tm z = *localtime(&now);
    
    ofstream output; //output file's pointer
  
		for(int i = 0;i<K;i++) {
		
		   
		  output.open("output.txt",ios::app);
		  output<<i+1<<"th CS requested at "<<z.tm_hour<<":"<<z.tm_min<<":"<<z.tm_sec<<":"<<ns.tv_nsec<<" by thread "<<id <<"\n";
		  output.close();
		
         	  while (lock.test_and_set());  //waiting section
		   
		  output.open("output.txt",ios::app);
                  output<<i+1<<"th CS entered at "<<z.tm_hour<<":"<<z.tm_min<<":"<<z.tm_sec<<":"<<ns.tv_nsec<<" by thread "<<id <<"\n";
		
		sleep(rand_exp(lambda1)/1000); // critical section simulation
		
		lock.clear();
		
		  output<<i+1<<"th CS exited at "<<z.tm_hour<<":"<<z.tm_min<<":"<<z.tm_sec<<":"<<ns.tv_nsec<<" by thread "<<id <<"\n";
		  output.close();
		  
		sleep(rand_exp(lambda2)/1000); //remainder section simulation
		}

free(a);
return NULL;
}



int main(int argc,char*argv[])
{
  ifstream ter;
  ter.open(argv[1]);
  ter >> N >> K >> lambda1 >> lambda2;
  ter.close();
  int i;
  
  ofstream output;
  output.open("output.txt",ios::app);
  output<<"TAS ME OUTPUT:\n";
  output.close();
  
  pthread_t A[N];
     
  for(i=0;i<N;i++) { 
  
  int*id = (int*)malloc(sizeof(int));
  
  *id = i ; 
  
  pthread_create(&A[i],NULL,pie,(void*)id);   // creating all threads
  
    
  }
  
  for(i=0;i<N;i++) pthread_join(A[i],NULL);     // waiting for all threads        
  
                            
 return 0;
}


