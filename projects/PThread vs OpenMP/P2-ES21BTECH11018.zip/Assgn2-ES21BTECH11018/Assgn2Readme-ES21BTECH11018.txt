INPUT :
Compile the code in terminal.
During the execution of ./a.out, write the input file next to it as command line argument(ex : input.txt).
The input.txt file must be in the same directory as source code.
for OpenMP thread code include -fopenmp after g++ in terminal.
The input file must contain a single value of N and K seperated by a space on first line followed by inputs of sudoku.

OUTPUT :
output.txt file will be generated.
It shows what thread validated what part of the sudoku.
Also whether sudoku is valid or not.
also time taken to compile.


A sample output would be something like this:-
Thread 1 checks row 1 and is valid.

Thread 2 checks column 2 and is valid.
Thread 3 checks grid 1 and is valid.
.
.
.
Thread i checks the grid m and is valid.
.
Thread j checks the row n and is invalid.


Sudoku is invalid.
The total time taken is 25.05 microseconds.
