#include <iostream>
#include <cstdlib>
#include <cmath>
#include <omp.h>
#include <unistd.h>
#include <ctime>
#include <fstream>
#include <chrono>

using namespace std ;
using namespace std::chrono ;

int N,n,rem,fac,K ;
int**p ;
int*Val ;


   bool sum(int a[])
   { 
     int i,b=0;
     for(i=0;i<N;i++) b = b + a[i] ;
     if(b==(-1)*N) return true;
     return false;
   }




						bool row(int a)
						{
						  a-- ;
						  int i;
						  int*Arr = (int*)calloc(sizeof(int),N);
						  
						  for(i=0;i<N;i++) if(p[a][i]<=N) Arr[p[a][i]-1] = -1;
						  
						  if(sum(Arr)) { 
						  
						   free(Arr); 
						   
						   return true;
						  }
						  
						  free(Arr);
						  return false ;
						}
						  
								bool column(int a)
								{
								  a-- ;
								  int i;
								  int*Arr = (int*)calloc(sizeof(int),N);
								  
								  for(i=0;i<N;i++) if(p[i][a]<=N) Arr[p[i][a]-1] = -1;
								  
								  if(sum(Arr)) { 
								  
								   free(Arr); 
								   
								   return true;
								  }
								  
								  free(Arr);
								  return false ;
								}
									

			bool sub(int a,int b)
			{
			  int i,j;
			  int*Arr = (int*)calloc(sizeof(int),N);
			  
			  for(i=(a*n);i<((a+1)*n);i++) 
			   { for(j=(b*n);j<((b+1)*n);j++)
			       {   if(p[i][j]<=N) Arr[p[i][j]-1] = -1;  }
			  }
			  if(sum(Arr)) { 
			  
			   free(Arr); 
			   
			   return true;
			  }
			  
			  free(Arr);
			  return false ;
			}





	void* pie(int h)
	{
	  int k;
	  
	  
	   if(h<=N) { if(row(h)) Val[h] = 1 ; }
	   else if(h<=(2*N)) { if(column(h-N)) Val[h] = 1 ; }
	   else
	   {
	     k = h - (2*N)-1 ;
	     if(sub((int)(k/n),k%n)) Val[h] = 1 ;   
	   }
	  
	  return NULL;

	}
	
	
	 void* pei(int h)
	{
	  
	  int i;
	  
	   for(i=((h-1)*fac)+1;i<= h*fac;i++) pie(i);
	   if(rem>0 && h<=(3*N)%K) pie((((int)(3*N)/K)*K)+h);
	   
	  return NULL;

	}


void solve_val(int*v,int time)
{
int i,a=0;
ofstream coutp;  
coutp.open("output.txt");
  		  
for(i=1;i<=N;i++)
{
if(v[i]==1 && a!=-1) coutp << "thread" << (int)(i*K)/(3*N) + 1 <<" found row"<<i<<" is vaild"<<"\n";
else if(a!=-1){a=-1; coutp << "thread" << (int)(i*K)/(3*N) + 1 <<" found row"<<i<<" is invaild"<<"\n";break;}
}

for(i=N+1;i<=(2*N);i++)
{
if(v[i]==1 && a!=-1) coutp << "thread" << (int)(i*K)/(3*N) + 1  <<" found column"<<i-N<<" is vaild"<<"\n";
else if(a!=-1) {a=-1;coutp << "thread" << (int)(i*K)/(3*N) + 1 <<" found column"<<i-N<<" is invaild"<<"\n";break;}
}

for(i=(2*N)+1;i<(3*N);i++)
{
if(v[i]==1 && a!=-1) coutp << "thread" << (int)(i*K)/(3*N) + 1  <<" found grid"<<i-(2*N)<<" is vaild"<<"\n";
else if(a!=-1) {a=-1;coutp << "thread" << (int)(i*K)/(3*N) + 1  <<" found grid"<<i-(2*N)<<" is invaild"<<"\n";break;}
}
if(v[3*N]==1 && a!=-1 ) coutp << "thread" << (int)(i*K)/(3*N) <<" found grid"<<i-(2*N)<<" is vaild"<<"\n";
else if(a!=-1){a=-1; coutp << "thread" << (int)(i*K)/(3*N) <<" found grid"<<i-(2*N)<<" is invaild"<<"\n";}

if(a==0) coutp << "\n" << "sudoku is valid" << "\n" ;
else coutp << "\n" << "sudoku is invalid" << "\n" ;
coutp << "The total time taken is " << time << " microseconds\n" ;
coutp.close();
return;
}





int main(int argc,char*argv[])
{
  ifstream ter;
  ter.open(argv[1]);
  ter >> K >> N ;
  p = (int**)malloc(sizeof(int*)*N) ;
  int i,j;
  for(i = 0;i<N ; i++) p[i] = (int*)malloc(sizeof(int)*N) ;  
  for(i=0;i<N;i++) for(j=0;j<N;j++) ter >> p[i][j] ;
  ter.close();
  
  
  Val = (int*)calloc(sizeof(int),(3*N)+1);
  
  n = (int)sqrt(N) ;
  
  rem = (3*N)%K;
  fac = (int)(3*N)/K;
  omp_set_num_threads(K) ;
  auto initial = high_resolution_clock::now() ;
  #pragma omp parallel
  {
  
    pei(omp_get_thread_num()+1);
  
  }
  auto finall = high_resolution_clock::now() ;
  
  auto time = duration_cast<microseconds>(finall-initial) ;
  
 for(i = 0;i<N ; i++) free(p[i]) ;
 free(p) ;
 
 solve_val(Val,(int)time.count());
 
 free(Val);
 
 return 0;
}
