#include <iostream>
#include <cstdlib>
#include <ctime>
#include <pthread.h>
#include <fstream>
#include <random>
#include <unistd.h>
#include <chrono>
#include <time.h>
#include <semaphore.h>

using namespace std ;
using namespace std::chrono ;

int n,m,k,c,lock=0,rid=0;
double lambda1,lambda2;
int*pt;


sem_t persons,cars,bi_sem,ubi_sem,bi_sem2,m_lok;


		double rand_exp(double lambda)
		{
		  unsigned random = system_clock::now().time_since_epoch().count();
		  default_random_engine time (random);
		  exponential_distribution<double>distribution(1/lambda) ;
		  
		  return distribution(time);
		}



void* people(void*p) { 
  
  int*a = (int*)p; 
  int id = *a ;
  id++;
  
    ofstream output;
    output.open("output.txt",ios::app); 
    struct timespec ns;
    timespec_get(&ns,TIME_UTC);
    time_t now;
    now = time(NULL);
    struct tm z = *localtime(&now);
    output<<"Passenger "<<id<<" enters the museum at "<<z.tm_hour<<":"<<z.tm_min<<":"<<z.tm_sec<<":"<<ns.tv_nsec<<"\n";
    output.close();
  
  int i;
  while(lock==0);
  
  for(i=0;i<k;i++){

      pt[id] = 0;
      usleep(rand_exp(lambda1)*1000);
      
      struct timespec ns2;
      timespec_get(&ns2,TIME_UTC);
      time_t now2;
      now2 = time(NULL);
      struct tm z2 = *localtime(&now2);
      output.open("output.txt",ios::app); 
      output<<"Passenger "<<id<<" made a ride request at "<<z2.tm_hour<<":"<<z2.tm_min<<":"<<z2.tm_sec<<":"<<ns2.tv_nsec<<"\n";
      output.close();
      
      sem_wait(&bi_sem);
      sem_wait(&cars);                 
      c = id;
      sem_post(&ubi_sem);
      
      while(pt[id]==0);

      struct timespec ns4;
      timespec_get(&ns4,TIME_UTC);
      time_t now4;
      now4 = time(NULL);
      struct tm z4 = *localtime(&now4);
      output.open("output.txt",ios::app);
      output<<"Passenger "<<id<<" finished riding at "<<z4.tm_hour<<":"<<z4.tm_min<<":"<<z4.tm_sec<<":"<<ns4.tv_nsec<<"\n";
      output.close();
      
      sem_post(&persons);
      
      }
  
    struct timespec ns1;
    timespec_get(&ns1,TIME_UTC);
    time_t now1;
    now1 = time(NULL);
    struct tm z1 = *localtime(&now1);
    output.open("output.txt",ios::app);
    output<<"Passenger "<<id<<" exits the museum at "<<z1.tm_hour<<":"<<z1.tm_min<<":"<<z1.tm_sec<<":"<<ns1.tv_nsec<<"\n";
    output.close();
       
   return NULL;
   
 }
      

		void* car(void*p){ 

		  int*a = (int*)p; 
		  int id = *a ;
		  id++;
		  int man;
		  ofstream output;
		  
		  while(lock==0);

		      sem_wait(&bi_sem2);
		      rid++;  
		      sem_post(&bi_sem2);

		      if(rid > (n*k)) return NULL;
		  
		      sem_wait(&ubi_sem);
		      sem_wait(&persons);     
		      man = c;
		      sem_post(&bi_sem);
		      
		      output.open("output.txt",ios::app);
		      output<< "Car "<<id<<" accepted Passenger "<< c <<"'s request\n" ; 
		      struct timespec ns3;
		      timespec_get(&ns3,TIME_UTC);
		      time_t now3;
		      now3 = time(NULL);
		      struct tm z3 = *localtime(&now3);
		      output<<"Passenger "<<man<<" started riding at "<<z3.tm_hour<<":"<<z3.tm_min<<":"<<z3.tm_sec<<":"<<ns3.tv_nsec<<"\n";
		      output<< "Car "<<id<<" is riding Passenger "<< man <<"\n" ;
		      output.close();     
		      
		      usleep(rand_exp(lambda2)*1000);

		      output.open("output.txt",ios::app);
		      output<< "Car "<<id<<" finished Passenger "<< man <<"'s tour\n" ;
		      output.close();
				 
		      pt[man] = 1;
		      sem_post(&cars);
		    
		    if(rid<=(n*k)) car(p);
		      
		   return NULL;
		   
		 }



int main(int argc,char*argv[])
{
  
  int i;
  
  ifstream ter;
  ter.open(argv[1]);
  ter >> n >> m >> k >> lambda1 >> lambda2;
  ter.close();  
 
  pt = (int*)calloc(n+1,sizeof(int));
  
  sem_init(&bi_sem,1,1);
  sem_init(&ubi_sem,1,0);
  sem_init(&bi_sem2,1,1);
  sem_init(&persons,1,n);
  sem_init(&cars,1,m);
  
  pthread_t A[n],B[m];
  
     
  for(i=0;i<n;i++) { 
    int*id = (int*)malloc(sizeof(int));
    *id = i ; 
    pthread_create(&A[i],NULL,people,(void*)id);   
  }
  
  for(i=0;i<m;i++) {
    int*id = (int*)malloc(sizeof(int));
    *id = i ; 
    pthread_create(&B[i],NULL,car,(void*)id);   
  }
  
  lock = 1;
  
  for(i=0;i<n;i++) pthread_join(A[i],NULL);
  for(i=0;i<m;i++) pthread_join(B[i],NULL);

  free(pt);
  sem_destroy(&ubi_sem);
  sem_destroy(&persons);
  sem_destroy(&cars);
  sem_destroy(&bi_sem);

 return(0);
  
}
