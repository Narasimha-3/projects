
INPUT :

Compile the code in terminal
during the execution of a.out, write the input file next to it as command line argument(ex:input.txt).

The input.txt file must be in the same directory as source code.

The input file must contain a single values of n,m,k,lambdaP,lambdaC seperated by a space on first line.(Ex : 500 200 30 20 50)

Here n is number of passenge threads to be used and m is number of car threads and k is the number of times each passenger thread to be executed.

OUTPUT :

output.txt file will be created.

A sample output is as follows:

Passenger 1 enters the museum at 12:00
Passenger 2 enters the museum at 12:01
Passenger 1 made a ride request at 12:01
Car 1 accepts passenger 1’s request
Passenger 1 started riding at 12:02
Car 1 is riding Passenger 1
Car 1 has finished Passenger 1’s tour
Passenger 1 finished riding at 12:04
.
.
.

Passenger 1 exit the museum at 12:10

Note : DELETE THE OUTPUT FILE BEFORE RUNNING OTHER CODE OR SAME CODE AGAIN BECAUSE ALL CODE WILL RIGHT NEWLY AFTER PREVIOUS OUTPUTS WITHOUT ERASING.(APPENDING)
