#include <iostream>
#include <cstdlib>
#include <ctime>
#include <pthread.h>
#include <fstream>
#include <chrono>


using namespace std ;
using namespace std::chrono ;

int n,id,N,K;        //n is the number of points inside circle,N is total number of points,K is number of threads,id is an unique number for each thread
double**q1;          //double array used as shared memory
pthread_mutex_t mute;




//prints the output in output.txt



void print(int time,double pi)
{ 
  int i,j,k,a;  // k is number of points inside circle for each thread,a is the range for each thread,i and j are just looping variables
  ofstream output;  
  output.open("output.txt");
  
  output<<"\nTime :" << time << "μs\n" ; 
  
  output<<"\nValue Computed :" << pi <<"\n" << "Log:\n" ;
  
  for(i=1;i<=K;i++)
  { 
    k = 0;
    a = (int)(N/K);
    if(i<=N%K)  a++ ;
    output<<"\nThread"<<i<<":\n" ;
    
    for(j=0 ;j < a; j++) if(q1[i][j]<-1) k++;
    output << "\nTotal number of points in circle are " << k << "\n" ;
    output << "\nTotal number of points in square are " << a << "\n" << "\nPoints inside the square:\n\n" ;
    for(j=0 ;j < a; j++) if(q1[i][j]>=-1) output<<"("<<q1[i][j]<<","<<q1[i][j+a]<<")," ;
    output <<"\n"<<"\nPoints inside the circle:\n\n" ;
    for(j=0 ;j < a; j++) if(q1[i][j]<-1) output<<"("<<q1[i][j]+5<<","<<q1[i][j+a]+5<<")," ;
   
  }
  output.close();
return;
}




//counts the value of n and returns all points verified by each thread

double*thread()
{
  int a = (int)(N/K);
  int i;
  double x,y;
  if(id<=N%K) a++;
  double*q = (double*)malloc(sizeof(double)*(2*a));
  srand(time(NULL));
  for(i=0;i<a;i++)
  {
    x = (double)(rand())/(double)RAND_MAX ;
    y = (double)(rand())/(double)RAND_MAX ;
    x = (2*x)-1;
    y = (2*y)-1;
  
    if(((x*x)+(y*y))<1) 
    {
    pthread_mutex_lock(&mute);
    n=n+1;
    pthread_mutex_unlock(&mute);
    q[i]=x-5;
    q[a+i]=y-5;
    }
    else
    {
    q[i]=x;
    q[a+i]=y;
    }
  }
    
  return q;  
 }




// calls thread function for each thread




void* pie(void*p)
{
  id++;
  int h = id;
  q1[h] = thread();
  return NULL;

}


//computes final pi value and time taken to compute,also calls respective functions to give output.txt



int main(int argc,char*argv[])
{
  id = 0;
  n=0;
  
  
  //taking input
  
  
  ifstream ter;
  ter.open(argv[1]);
  ter >> N >> K ;
  ter.close();
  
  q1 = (double**)malloc(sizeof(double*)*(K+1));    //allocating dynamic memory to double array
  int i,j ;
  
  
  pthread_t A[K];
  pthread_mutex_init(&mute,NULL) ;
  
  auto initial = high_resolution_clock::now() ;         //starting stopwatch
  for(i=0;i<K;i++) pthread_create(&A[i],NULL,pie,NULL);  //creating threads
  for(i=0;i<K;i++) pthread_join(A[i],NULL);             //waiting for threads
  pthread_mutex_destroy(&mute) ;
  auto finall = high_resolution_clock::now() ;          //ending stopwatch
  auto time = duration_cast<microseconds>(finall-initial) ;
  
  print((int)time.count(),(double)(4*n)/(double)N );   //giving output
 
  
  for(i=0;i<K;i++) free(q1[i+1]);      //deallocating all threads memory
  
  free(q1);                                 //deallocating double array
 return 0;
}

