
INPUT :

Compile the code in terminal
during the execution of a.out, write the input file next to it as command line argument(ex:input.txt).

The input.txt file must be in the same directory as source code.

The input file must contain a single value of N and K seperated by a space on first line.(Ex : 500 30)

Here N is number of points validating and K is number of threads to be used.

OUTPUT :

output.txt files will be created.

Initially the time taken to compute pi will be printed.

Then the value of pi computed by all threads together is printed.

Then the number of points in circle and square computed by each thread along with the points diffrentiated based on whether they are in square or circle are written.


NOTE : on takibg million points the output.txt is becoming 30mb which requires atleast 5mins to complete,so better use vim to open output.txt. 
